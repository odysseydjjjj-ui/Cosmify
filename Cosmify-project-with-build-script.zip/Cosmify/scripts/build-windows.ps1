$ErrorActionPreference = "Stop"
dotnet workload install maui-windows
dotnet restore "$PSScriptRoot\..\Cosmify.sln"
dotnet publish "$PSScriptRoot\..\src\Cosmify\Cosmify.csproj" -f net10.0-windows10.0.19041.0 -c Release -p:WindowsPackageType=None
Write-Host "Windows output: src/Cosmify/bin/Release/net10.0-windows10.0.19041.0/win10-x64/publish/"
