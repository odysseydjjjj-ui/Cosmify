$ErrorActionPreference = "Stop"
dotnet workload install maui-android
dotnet restore "$PSScriptRoot\..\Cosmify.sln"
dotnet publish "$PSScriptRoot\..\src\Cosmify\Cosmify.csproj" -f net10.0-android -c Release -p:AndroidPackageFormat=apk
Write-Host "APK output: src/Cosmify/bin/Release/net10.0-android/publish/"
