$ErrorActionPreference = "Stop"
Get-ChildItem "$PSScriptRoot\.." -Directory -Recurse -Force |
  Where-Object { $_.Name -in @("bin", "obj") } |
  Remove-Item -Recurse -Force
