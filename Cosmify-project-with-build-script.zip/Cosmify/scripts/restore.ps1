$ErrorActionPreference = "Stop"
dotnet workload install maui
dotnet restore "$PSScriptRoot\..\Cosmify.sln"
