$ErrorActionPreference = 'Stop'
$project = Join-Path $PSScriptRoot '..\src\Cosmify\Cosmify.csproj'
$project = [System.IO.Path]::GetFullPath($project)

Write-Host '=== Cosmify: checking .NET SDK ===' -ForegroundColor Cyan
try { dotnet --version } catch {
  Write-Error 'The .NET 10 SDK is not installed or dotnet is not on PATH. Install Visual Studio 2026 with .NET MAUI and Android components, then reopen this script.'
  exit 1
}

Write-Host '=== Restoring workloads and NuGet packages ===' -ForegroundColor Cyan
dotnet workload restore $project
if ($LASTEXITCODE -ne 0) { Write-Error 'Workload restore failed.'; exit $LASTEXITCODE }
dotnet restore $project
if ($LASTEXITCODE -ne 0) { Write-Error 'NuGet restore failed.'; exit $LASTEXITCODE }

$androidOk = $false
$windowsOk = $false

Write-Host '=== Building Android APK ===' -ForegroundColor Cyan
dotnet publish $project -f net10.0-android -c Release -p:AndroidPackageFormat=apk
if ($LASTEXITCODE -eq 0) { $androidOk = $true } else { Write-Warning 'Android build failed; continuing with Windows.' }

Write-Host '=== Building Windows app ===' -ForegroundColor Cyan
dotnet publish $project -f net10.0-windows10.0.19041.0 -c Release -r win-x64 -p:WindowsPackageType=None
if ($LASTEXITCODE -eq 0) { $windowsOk = $true } else { Write-Warning 'Windows build failed.' }

Write-Host ''
Write-Host '=== Results ===' -ForegroundColor Cyan
if ($androidOk) {
  Write-Host 'Android publish folder: src\Cosmify\bin\Release\net10.0-android\' -ForegroundColor Green
  Get-ChildItem (Join-Path (Split-Path $project) 'bin\Release\net10.0-android') -Recurse -Filter *.apk -ErrorAction SilentlyContinue | Select-Object -ExpandProperty FullName
} else { Write-Host 'Android: NOT BUILT' -ForegroundColor Red }
if ($windowsOk) {
  Write-Host 'Windows publish folder: src\Cosmify\bin\Release\net10.0-windows10.0.19041.0\' -ForegroundColor Green
} else { Write-Host 'Windows: NOT BUILT' -ForegroundColor Red }
if (-not ($androidOk -and $windowsOk)) { exit 1 }
Write-Host 'Both builds completed. Install the APK on Android and run the Windows executable from its publish folder.' -ForegroundColor Green
