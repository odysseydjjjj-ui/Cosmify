using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using Cosmify.Audio;
using Cosmify.Models;
using Cosmify.Services;

namespace Cosmify.ViewModels;
public sealed class MainViewModel : INotifyPropertyChanged
{
    private readonly LibraryService _library;
    private readonly IPlayerService _player;
    private string _search = "";
    private Track? _currentTrack;
    public ObservableCollection<Track> Tracks { get; } = [];
    public ObservableCollection<Track> VisibleTracks { get; } = [];
    public string SearchText { get => _search; set { _search = value; OnPropertyChanged(); _ = RefreshAsync(); } }
    public Track? CurrentTrack { get => _currentTrack; private set { _currentTrack = value; OnPropertyChanged(); } }
    public event PropertyChangedEventHandler? PropertyChanged;
    public MainViewModel(LibraryService library, IPlayerService player) { _library = library; _player = player; }
    public async Task InitializeAsync() => await RefreshAsync();
    public async Task RefreshAsync()
    {
        var result = await _library.SearchAsync(_search);
        await MainThread.InvokeOnMainThreadAsync(() =>
        {
            Tracks.Clear(); VisibleTracks.Clear();
            foreach (var t in result) { Tracks.Add(t); VisibleTracks.Add(t); }
        });
    }
    public async Task ImportAsync()
    {
        var result = await FilePicker.Default.PickMultipleAsync(new PickOptions { PickerTitle = "Выберите музыкальные файлы" });
        if (result is null) return;
        await _library.ImportFilesAsync(result.Select(x => x.FullPath));
        await RefreshAsync();
    }
    public async Task PlayAsync(Track track)
    {
        CurrentTrack = track;
        track.LastPlayedAt = DateTime.UtcNow;
        await _library.SaveTrackAsync(track);
        await _player.PlayAsync(track.FilePath);
    }
    public async Task FavoriteAsync(Track track) { await _library.ToggleFavoriteAsync(track); await RefreshAsync(); }
    private void OnPropertyChanged([CallerMemberName] string? name = null) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
}
