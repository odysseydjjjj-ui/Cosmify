using SQLite;
using Cosmify.Models;
namespace Cosmify.Data;

public sealed class LibraryDatabase
{
    private readonly SQLiteAsyncConnection _db;
    private readonly SemaphoreSlim _initLock = new(1, 1);
    private bool _initialized;

    public LibraryDatabase()
    {
        var path = Path.Combine(FileSystem.AppDataDirectory, "cosmify.db3");
        _db = new SQLiteAsyncConnection(path);
    }

    public async Task InitializeAsync()
    {
        if (_initialized) return;
        await _initLock.WaitAsync();
        try
        {
            if (_initialized) return;
            await _db.CreateTableAsync<Track>();
            await _db.CreateTableAsync<Playlist>();
            await _db.CreateTableAsync<PlaylistTrack>();
            _initialized = true;
        }
        finally { _initLock.Release(); }
    }

    public async Task<List<Track>> GetTracksAsync()
    {
        await InitializeAsync();
        return await _db.Table<Track>().OrderBy(x => x.Title).ToListAsync();
    }
    public async Task<int> SaveTrackAsync(Track track)
    {
        await InitializeAsync();
        if (track.Id == 0) return await _db.InsertAsync(track);
        return await _db.UpdateAsync(track);
    }
    public async Task<int> DeleteTrackAsync(Track track)
    {
        await InitializeAsync();
        // Removes only the library record, never the original media file.
        var removed = await _db.DeleteAsync(track);
        await _db.Table<PlaylistTrack>().Where(x => x.TrackId == track.Id).DeleteAsync();
        return removed;
    }
    public async Task<List<Playlist>> GetPlaylistsAsync()
    {
        await InitializeAsync();
        return await _db.Table<Playlist>().OrderBy(x => x.Name).ToListAsync();
    }
    public async Task<int> SavePlaylistAsync(Playlist playlist)
    {
        await InitializeAsync();
        return playlist.Id == 0 ? await _db.InsertAsync(playlist) : await _db.UpdateAsync(playlist);
    }
    public async Task AddToPlaylistAsync(int playlistId, int trackId)
    {
        await InitializeAsync();
        var count = await _db.Table<PlaylistTrack>().Where(x => x.PlaylistId == playlistId).CountAsync();
        await _db.InsertAsync(new PlaylistTrack { PlaylistId = playlistId, TrackId = trackId, Position = count });
    }
}
