using CommunityToolkit.Maui.Views;
namespace Cosmify.Audio;

// The MediaElement is hosted by MainPage. Platform media-session/background controls
// require native Android service integration and are intentionally not claimed here.
public sealed class MediaElementPlayerService : IPlayerService
{
    private MediaElement? _element;
    public bool IsPlaying => _element?.CurrentState == MediaElementState.Playing;
    public void Attach(MediaElement element) => _element = element;
    public Task PlayAsync(string path)
    {
        if (_element is null) throw new InvalidOperationException("Аудиоплеер ещё не подключён.");
        MainThread.BeginInvokeOnMainThread(() => _element.Source = MediaSource.FromFile(path));
        return Task.CompletedTask;
    }
    public Task PauseAsync()
    {
        MainThread.BeginInvokeOnMainThread(() => _element?.Pause());
        return Task.CompletedTask;
    }
    public Task StopAsync()
    {
        MainThread.BeginInvokeOnMainThread(() => _element?.Stop());
        return Task.CompletedTask;
    }
}
