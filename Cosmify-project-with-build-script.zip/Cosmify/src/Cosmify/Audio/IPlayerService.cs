namespace Cosmify.Audio;
public interface IPlayerService
{
    Task PlayAsync(string path);
    Task PauseAsync();
    Task StopAsync();
    bool IsPlaying { get; }
}
