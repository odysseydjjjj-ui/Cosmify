using Cosmify.Audio;
using Cosmify.Models;
using Cosmify.ViewModels;

namespace Cosmify;
public partial class MainPage : ContentPage
{
    private readonly MainViewModel _vm;
    private readonly MediaElementPlayerService _player;
    public MainPage(MainViewModel vm, IPlayerService player)
    {
        InitializeComponent();
        _vm = vm;
        _player = (MediaElementPlayerService)player;
        BindingContext = vm;
        _player.Attach(AudioElement);
        Loaded += async (_, _) => await _vm.InitializeAsync();
    }
    private async void OnImportClicked(object sender, EventArgs e) => await _vm.ImportAsync();
    private async void OnPlayClicked(object sender, EventArgs e)
    {
        if ((sender as Button)?.CommandParameter is Track track) await _vm.PlayAsync(track);
    }
    private async void OnFavoriteClicked(object sender, EventArgs e)
    {
        if ((sender as Button)?.CommandParameter is Track track) await _vm.FavoriteAsync(track);
    }
    private async void OnPauseClicked(object sender, EventArgs e) => await _player.PauseAsync();
    private async void OnStopClicked(object sender, EventArgs e) => await _player.StopAsync();
}
