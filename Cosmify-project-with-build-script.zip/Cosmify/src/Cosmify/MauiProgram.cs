using CommunityToolkit.Maui;
using CommunityToolkit.Maui.MediaElement;
using Cosmify.Audio;
using Cosmify.Data;
using Cosmify.Services;
using Cosmify.ViewModels;

namespace Cosmify;
public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder.UseMauiApp<App>().UseMauiCommunityToolkit().UseMauiCommunityToolkitMediaElement();
        builder.Services.AddSingleton<LibraryDatabase>();
        builder.Services.AddSingleton<LibraryService>();
        builder.Services.AddSingleton<IFileMetadataReader, TagLibMetadataReader>();
        builder.Services.AddSingleton<IPlayerService, MediaElementPlayerService>();
        builder.Services.AddSingleton<MainViewModel>();
        builder.Services.AddSingleton<MainPage>();
        return builder.Build();
    }
}
