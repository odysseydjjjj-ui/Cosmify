namespace Cosmify;
public partial class App : Application
{
    public App(MainPage page)
    {
        InitializeComponent();
        MainPage = new NavigationPage(page) { BarBackgroundColor = Color.FromArgb("#211638"), BarTextColor = Colors.White };
    }
}
