using Cosmify.Data;
using Cosmify.Models;
namespace Cosmify.Services;

public sealed class LibraryService(LibraryDatabase database, IFileMetadataReader metadata)
{
    private static readonly HashSet<string> Extensions = new(StringComparer.OrdinalIgnoreCase)
        { ".mp3", ".flac", ".wav", ".ogg", ".m4a", ".aac", ".opus" };

    public Task<List<Track>> GetAllAsync() => database.GetTracksAsync();

    public async Task<int> ImportFilesAsync(IEnumerable<string> paths, CancellationToken token = default)
    {
        var imported = 0;
        var existing = (await database.GetTracksAsync()).Select(t => t.FilePath).ToHashSet(StringComparer.OrdinalIgnoreCase);
        foreach (var path in paths.Where(p => Extensions.Contains(Path.GetExtension(p))))
        {
            token.ThrowIfCancellationRequested();
            if (!File.Exists(path) || existing.Contains(path)) continue;
            try { await database.SaveTrackAsync(await metadata.ReadAsync(path, token)); imported++; }
            catch (Exception ex) when (ex is not OperationCanceledException) { System.Diagnostics.Debug.WriteLine(ex); }
        }
        return imported;
    }

    public async Task<List<Track>> SearchAsync(string query)
    {
        var tracks = await database.GetTracksAsync();
        if (string.IsNullOrWhiteSpace(query)) return tracks;
        return tracks.Where(t => $"{t.Title} {t.Artist} {t.Album}".Contains(query, StringComparison.CurrentCultureIgnoreCase)).ToList();
    }
    public Task<int> SaveTrackAsync(Track track) => database.SaveTrackAsync(track);

    public Task<int> ToggleFavoriteAsync(Track track)
    {
        track.IsFavorite = !track.IsFavorite;
        return database.SaveTrackAsync(track);
    }
    public Task<int> RemoveFromLibraryAsync(Track track) => database.DeleteTrackAsync(track);
}
