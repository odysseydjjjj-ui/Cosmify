using Cosmify.Models;
namespace Cosmify.Services;

public interface IFileMetadataReader
{
    Task<Track> ReadAsync(string path, CancellationToken cancellationToken = default);
}
public sealed class TagLibMetadataReader : IFileMetadataReader
{
    public Task<Track> ReadAsync(string path, CancellationToken cancellationToken = default) =>
        Task.Run(() =>
        {
            cancellationToken.ThrowIfCancellationRequested();
            using var file = TagLib.File.Create(path);
            var title = string.IsNullOrWhiteSpace(file.Tag.Title) ? Path.GetFileNameWithoutExtension(path) : file.Tag.Title;
            return new Track
            {
                FilePath = path, Title = title,
                Artist = file.Tag.FirstPerformer ?? "Неизвестный исполнитель",
                Album = file.Tag.Album ?? "",
                DurationMs = (long)file.Properties.Duration.TotalMilliseconds
            };
        }, cancellationToken);
}
