namespace Cosmify.Integrations;

public enum IntegrationState { NotConnected, Ready, RequiresConfiguration, Unsupported }
public sealed record IntegrationInfo(string Name, string Description, IntegrationState State, string NextStep);

/// <summary>Honest capability registry. No fake catalogues or simulated successful connections.</summary>
public static class IntegrationCatalog
{
    public static IReadOnlyList<IntegrationInfo> All { get; } =
    [
        new("Bandcamp", "Каталог и воспроизведение только через разрешённые официальные интерфейсы.", IntegrationState.RequiresConfiguration, "Проверить доступность официального API/партнёрского доступа."),
        new("Audiomack", "Интеграция каталога требует подтверждённого доступа.", IntegrationState.RequiresConfiguration, "Получить официальные условия доступа."),
        new("Jamendo", "Для каталога требуется API-ключ Jamendo.", IntegrationState.RequiresConfiguration, "Добавить собственный API Client ID в локальную конфигурацию."),
        new("Free Music Archive", "Источник требует проверки актуального API.", IntegrationState.RequiresConfiguration, "Подключить подтверждённый API."),
        new("Internet Archive", "Метаданные доступны через публичные API; воспроизведение зависит от прав на конкретный объект.", IntegrationState.RequiresConfiguration, "Реализовать поиск и проверку прав на уровне элемента."),
        new("Musopen", "Доступность API и лицензии контента необходимо подтвердить.", IntegrationState.RequiresConfiguration, "Проверить актуальные условия Musopen."),
        new("YouTube / VK Видео / Rutube / TikTok", "Использовать официальное встраивание или открытие оригинала; не обходить ограничения.", IntegrationState.NotConnected, "Добавлять адаптеры отдельно после проверки правил каждой платформы."),
        new("Discord Rich Presence", "RPC требует локального Discord-клиента и отдельной платформенной реализации.", IntegrationState.NotConnected, "Настроить Discord Application ID и нативный RPC-адаптер.")
    ];
}
