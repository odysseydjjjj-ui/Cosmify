using SQLite;
namespace Cosmify.Models;
[Table("Playlists")]
public sealed class Playlist
{
    [PrimaryKey, AutoIncrement] public int Id { get; set; }
    public string Name { get; set; } = "Новый плейлист";
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
[Table("PlaylistTracks")]
public sealed class PlaylistTrack
{
    [PrimaryKey, AutoIncrement] public int Id { get; set; }
    [Indexed] public int PlaylistId { get; set; }
    [Indexed] public int TrackId { get; set; }
    public int Position { get; set; }
}
