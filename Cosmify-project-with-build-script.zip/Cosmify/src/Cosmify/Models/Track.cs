using SQLite;
namespace Cosmify.Models;

[Table("Tracks")]
public sealed class Track
{
    [PrimaryKey, AutoIncrement] public int Id { get; set; }
    [Indexed] public string FilePath { get; set; } = "";
    public string Title { get; set; } = "Неизвестный трек";
    public string Artist { get; set; } = "Неизвестный исполнитель";
    public string Album { get; set; } = "";
    public long DurationMs { get; set; }
    public bool IsFavorite { get; set; }
    public DateTime AddedAt { get; set; } = DateTime.UtcNow;
    public DateTime? LastPlayedAt { get; set; }
}
